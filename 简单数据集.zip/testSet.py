# -*- coding: utf-8 -*-
"""
Created on Sat May 29 20:50:42 2021

@author: MaYiming
"""
import numpy as np
import matplotlib.pyplot as plt

params={}
params["Train_path"] = 'testSet.txt'

def loadData(FilePath):
    DataSet = []
    with open(FilePath) as p:
        for line in p:
            DataSet.append(line.strip().split('\t'))
    return np.array(DataSet).astype(float)
DataSet = loadData(params["Train_path"])
def PCA(DataSet,k):
    m = DataSet.shape[0]
    #这里DataSet是行向量，如果按照数学公式需要逆转
    #去中心化
    MeanSet = np.mean(DataSet,axis = 0)
    DataSet = DataSet-MeanSet
    #数学里边是XX^T，这里反过来
    #计算协方差
    cov = (DataSet.T).dot(DataSet)/(m-1)
    #特征向量分解,按理说特征向量分解可以有很多，因为特征值和向量可同时缩放
    #但在这里，我们需要的是一个WW^T=E的特征值矩阵，即所有的特征向量应该是
    #归一化的，但这里不需要我们特殊操作，eig这个模型已经帮我们做好了这一步
    #特征值与特征向量分解
    Fval,Fvec = np.linalg.eig(cov)
    #利用argsort得到按照从小到大排序的下标列表
    sorted_indices = np.argsort(Fval)
    #取后K个，也就是最大的几个
    W = Fvec[:,sorted_indices[-k:]]
    #lamb = Fval[sorted_indices[-k:]] #没什么用
    #得到降维之后的Z
    #Z = W^T X
    Z = (W.T).dot(DataSet.T)
    #将降维数据还原到原特征空间
    #注意这里的还原不是指还原为以前的散点，而是把这个一维线性在二维里表示
    #从而更好的看降维的效果
    #Z=W^T X 所以WZ=WW^TX=X
    X = W.dot(Z).T
    #恢复去中心化
    X += MeanSet
    return X
a = PCA(DataSet,1)
plt.xlabel('X')
plt.ylabel('Y')
plt.scatter(DataSet[:,0],DataSet[:,1])
plt.scatter(a[:,0], a[:,1])
