# -*- coding: utf-8 -*-
"""
Created on Mon May 31 11:29:20 2021

@author: MaYiming
"""
import numpy as np
import os
from PIL import Image
import matplotlib.pyplot as plt
import cv2 as cv

params={}
params["Train_path"] = 'project1-data-Recognition\\'
params["class"] = ['centerlight','glasses','happy','leftlight','noglasses',
                   'normal','rightlight','sad','sleepy','surprised','wink']
params["N"] = 5
params["Resize_H"] = 40
params["Resize_W"] = 30

def loadData(params):
    DataSet = []
    LabelSet = []
    FilePath = params["Train_path"]
    for index in range(1,16):
        for clas in params["class"]:
            if 1<=index<=9:
                img_path = os.path.join(FilePath,"subject0"+str(index)+'.'+clas+'.pgm')
                LabelSet.append("subject0"+str(index))
            else:
                img_path = os.path.join(FilePath,"subject"+str(index)+'.'+clas+'.pgm')
                LabelSet.append("subject"+str(index))
            img = Image.open(img_path)
            #img = np.reshape(np.array(img),(1,231*195))
            img = np.array(img)
            img = cv.resize(img,(params["Resize_H"],params["Resize_W"]))
            DataSet.append(img)
    DataSet = np.array(DataSet)
    LabelSet = np.array(LabelSet)
    #print(DataSet.shape)
    return DataSet,LabelSet
def DataShuffle(DataSet,LabelSet,N):
    TrainDataSet = []
    TrainLabelSet = []
    TestDataSet = []
    TestLabelSet = []
    
    for i in range(15):
        DAL = []
        for j in range(11):
            DAL.append((DataSet[11*i+j],LabelSet[11*i+j]))
        DAL = np.array(DAL)
        np.random.shuffle(DAL)
        for k in range(11):
            if k<N:
                TrainDataSet.append(DAL[k][0])
                TrainLabelSet.append(DAL[k][1])
            else:
                TestDataSet.append(DAL[k][0])
                TestLabelSet.append(DAL[k][1])
    TrainDataSet = np.array(TrainDataSet)
    TrainLabelSet = np.array(TrainLabelSet)
    TestDataSet = np.array(TestDataSet)
    TestLabelSet = np.array(TestLabelSet)
    return TrainDataSet,TrainLabelSet,TestDataSet,TestLabelSet
DataSet, LabelSet = loadData(params)
TrainDataSet,TrainLabelSet,TestDataSet,TestLabelSet = DataShuffle(DataSet, LabelSet, params["N"])
#print(TrainDataSet.shape,TrainLabelSet.shape,TestDataSet.shape,TestLabelSet.shape)
TrainDataSet = np.reshape(TrainDataSet, (15*params["N"],params["Resize_H"]*params["Resize_W"]))
TestDataSet = np.reshape(TestDataSet,(15*(11-params["N"]),params["Resize_H"]*params["Resize_W"]))
#print(TestDataSet.shape,TrainDataSet.shape)
def LDA_dimensionality(DataSet, LabelSet, k):
    '''
    DataSet为数据集，LabelSet为label，k为目标维数
    '''
    label_ = list(set(LabelSet))
    Data_classify = {}
    for label in label_:
        X1 = np.array([DataSet[i] for i in range(len(DataSet)) if LabelSet[i] == label])
        Data_classify[label] = X1
    mju = np.mean(DataSet, axis=0)
    mju_classify = {}
    for label in label_:
        mju1 = np.mean(Data_classify[label], axis=0)
        mju_classify[label] = mju1
    Sw = np.zeros((len(mju), len(mju)))  # 计算类内散度矩阵
    
    for i in label_:
        Sw += ((Data_classify[i] - mju_classify[i]).T).dot((Data_classify[i] - mju_classify[i]))
    # Sb=St-Sw
    Sb = np.zeros((len(mju), len(mju)))  # 计算类内散度矩阵
    for i in label_:
        Sb += len(Data_classify[i]) * np.dot((mju_classify[i] - mju).reshape(
            (len(mju), 1)), (mju_classify[i] - mju).reshape((1, len(mju))))
    eig_vals, eig_vecs = np.linalg.eig(
        np.linalg.pinv(Sw).dot(Sb))  # 计算Sw-1*Sb的特征值和特征矩阵
    sorted_indices = np.argsort(eig_vals)
    # 提取前k个特征向量
    topk_eig_vecs = eig_vecs[sorted_indices[-k:],:]
    return topk_eig_vecs.astype(float)
W = LDA_dimensionality(TrainDataSet,TrainLabelSet,10)

def TrainFeature(TrainDataSet,W):
    return TrainDataSet.dot(W.T)
FeatureMatrix = TrainFeature(TrainDataSet, W)
def TestOne(FeatureMatrix,LabelSet,testvec,testlabel):
    mini = np.sum((FeatureMatrix[0]-testvec)*(FeatureMatrix[0]-testvec))
    mini_index = 0
    for index,ele in enumerate(FeatureMatrix):
        tem = np.sum((FeatureMatrix[index]-testvec)*(FeatureMatrix[index]-testvec))
        if tem < mini:
            mini = tem
            mini_index = index
    #print(LabelSet[mini_index],testlabel)
    if LabelSet[mini_index] == testlabel:
        return 0
    else:
        return 1
#print(AveVec.shape)
def Test(FeatureMatrix,LabelSet,TestDataSet,TestLabelSet,W):
    m = TestDataSet.shape[0]
    err = 0
    for i in range(m):
        testvec = W.dot(TestDataSet[i])
        testlabel = TestLabelSet[i]
        res = TestOne(FeatureMatrix,LabelSet,testvec,testlabel)
        err += res
    errRate = err/m
    print(errRate)
Test(FeatureMatrix,LabelSet,TestDataSet,TestLabelSet,W)