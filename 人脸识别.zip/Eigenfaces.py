# -*- coding: utf-8 -*-
"""
Created on Sun May 30 19:22:50 2021

@author: MaYiming
"""
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
import os

params={}
params["Train_path"] = 'project1-data-Recognition\\'
params["class"] = ['centerlight','glasses','happy','leftlight','noglasses',
                   'normal','rightlight','sad','sleepy','surprised','wink']
params["N"] = 7
def loadData(params):
    DataSet = []
    LabelSet = []
    FilePath = params["Train_path"]
    for index in range(1,16):
        for clas in params["class"]:
            if 1<=index<=9:
                img_path = os.path.join(FilePath,"subject0"+str(index)+'.'+clas+'.pgm')
                LabelSet.append("subject0"+str(index))
            else:
                img_path = os.path.join(FilePath,"subject"+str(index)+'.'+clas+'.pgm')
                LabelSet.append("subject"+str(index))
            img = Image.open(img_path)
            #img = np.reshape(np.array(img),(1,231*195))
            img = np.array(img)
            DataSet.append(img)
    DataSet = np.array(DataSet)
    LabelSet = np.array(LabelSet)
    #print(DataSet.shape)
    return DataSet,LabelSet
def DataShuffle(DataSet,LabelSet,N):
    TrainDataSet = []
    TrainLabelSet = []
    TestDataSet = []
    TestLabelSet = []
    
    for i in range(15):
        DAL = []
        for j in range(11):
            DAL.append((DataSet[11*i+j],LabelSet[11*i+j]))
        DAL = np.array(DAL)
        np.random.shuffle(DAL)
        for k in range(11):
            if k<N:
                TrainDataSet.append(DAL[k][0])
                TrainLabelSet.append(DAL[k][1])
            else:
                TestDataSet.append(DAL[k][0])
                TestLabelSet.append(DAL[k][1])
    TrainDataSet = np.array(TrainDataSet)
    TrainLabelSet = np.array(TrainLabelSet)
    TestDataSet = np.array(TestDataSet)
    TestLabelSet = np.array(TestLabelSet)
    return TrainDataSet,TrainLabelSet,TestDataSet,TestLabelSet
DataSet, LabelSet = loadData(params)
TrainDataSet,TrainLabelSet,TestDataSet,TestLabelSet = DataShuffle(DataSet, LabelSet, params["N"])
#print(TrainDataSet.shape,TrainLabelSet.shape,TestDataSet.shape,TestLabelSet.shape)
TrainDataSet = np.reshape(TrainDataSet, (15*params["N"],231*195))
TestDataSet = np.reshape(TestDataSet,(15*(11-params["N"]),231*195))
#print(DataSet.shape,LabelSet.shape)
def Eigenfaces(DataSet, K):
    m,n = DataSet.shape
    #AveVec = np.reshape(DataSet[0],(231,195))
    AveVec = np.sum(DataSet,axis=0)/m
    AveVec = np.reshape(AveVec,(231,195))
    MeanSet = np.mean(DataSet,axis = 0)
    A = DataSet - MeanSet
    L = A.dot(A.T)
    #print(L.shape)
    Fval,Fvec = np.linalg.eig(L)
    F_m = len(Fval)
    Fvec = Fvec.astype(float)
    W = np.array([[0.0 for i in range(len(A[0]))]for x in range(F_m)])
    for l in range(F_m):
        for k in range(F_m):
            W[l] += Fvec[l][k]*A[k]
    sorted_indices = np.argsort(Fval)
    #取后K个，也就是最大的几个
    W = W[sorted_indices[-K:],:]
    return W,AveVec
def TrainFeature(TrainDataSet,W):
    return TrainDataSet.dot(W.T)

def TestOne(FeatureMatrix,LabelSet,testvec,testlabel):
    mini = np.sum((FeatureMatrix[0]-testvec)*(FeatureMatrix[0]-testvec))
    mini_index = 0
    for index,ele in enumerate(FeatureMatrix):
        tem = np.sum((FeatureMatrix[index]-testvec)*(FeatureMatrix[index]-testvec))
        if tem < mini:
            mini = tem
            mini_index = index
    #print(LabelSet[mini_index],testlabel)
    if LabelSet[mini_index] == testlabel:
        return 0
    else:
        return 1
#print(AveVec.shape)
def Test(FeatureMatrix,LabelSet,TestDataSet,TestLabelSet,W):
    m = TestDataSet.shape[0]
    err = 0
    for i in range(m):
        testvec = W.dot(TestDataSet[i])
        testlabel = TestLabelSet[i]
        res = TestOne(FeatureMatrix,LabelSet,testvec,testlabel)
        err += res
    errRate = err/m
    return errRate

#平均脸绘制
# AveVec = np.reshape(AveVec, (231,195))
# img = Image.fromarray(AveVec)
# plt.imshow(img)
# plt.axis("off")
err = []

for k in range(1,100):
    W,AveVec = Eigenfaces(TrainDataSet,k)
    FeatureMatrix = TrainFeature(TrainDataSet, W)
    err.append(Test(FeatureMatrix,LabelSet,TestDataSet,TestLabelSet,W))
plt.xlabel("number of k")
plt.ylabel("rate")
plt.plot(err)
#特征脸谱图绘制
# plt.figure()
# for i in range(1,7):
#     a = np.reshape(W[i],(231,195))
#     img = Image.fromarray(a)    
#     plt.subplot(2,3,i) 
#     plt.imshow(img)
#     plt.axis('off')